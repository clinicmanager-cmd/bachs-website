# BACH Website (Next.js)

A Next.js 14 App Router site for Bay Area Custom Health Solutions.

## Quick start

```bash
# 1) Unzip, then in the folder:
npm install

# 2) Run locally
npm run dev
# open http://localhost:3000
```

## Pages
- `/` — Home
- `/services`
- `/providers`
- `/policies`
- `/forms`

## Customize
- Replace the placeholder logo at `public/logo.svg` with your real logo (same filename).
- Edit content in the files under `app/` — they are simple React components.
- Update brand colors in `app/globals.css` (`--primary` etc.).
- The email contact buttons target clinicmanager@bayareachs.com.

## Deploy
- **Vercel** (recommended): Import the repo, no config required.
- **Netlify**: Build command `npm run build`, publish directory `.next` (use Next on Netlify plugin).
- **GitHub Pages**: Not ideal for SSR; use Vercel for best DX.

## Notes
- This project uses TypeScript by default.
- You can add Tailwind later (`npm i -D tailwindcss postcss autoprefixer && npx tailwindcss init -p`).

(c) 2025 Bay Area Custom Health Solutions
