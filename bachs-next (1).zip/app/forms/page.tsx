export default function FormsPage(){
  return (
    <section className="section">
      <div className="container">
        <h1>Forms</h1>
        <p>Download and complete prior to your visit when possible.</p>
        <div className="cards">
          <article className="card">
            <h3>New Patient Intake</h3>
            <p><a className="btn" href="mailto:clinicmanager@bayareachs.com?subject=New%20Patient%20Intake%20Request">Request by email</a></p>
          </article>
          <article className="card">
            <h3>Consent &amp; Policies</h3>
            <p><a className="btn" href="mailto:clinicmanager@bayareachs.com?subject=Consent%20Forms%20Request">Request by email</a></p>
          </article>
          <article className="card">
            <h3>Insurance Superbills</h3>
            <p><a className="btn" href="mailto:clinicmanager@bayareachs.com?subject=Superbill%20Request">Request by email</a></p>
          </article>
        </div>
      </div>
    </section>
  )
}
