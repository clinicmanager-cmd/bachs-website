import type { Metadata } from 'next'
import './globals.css'
import Nav from '@/components/Nav'
import Footer from '@/components/Footer'

export const metadata: Metadata = {
  title: 'Bay Area Custom Health Solutions',
  description: 'Regenerative & Functional Medicine • Hormone Therapy • IV Infusion Therapy • Medical Aesthetics — Coos Bay, OR',
  metadataBase: new URL('https://www.bayareachs.com'),
  openGraph: {
    title: 'Bay Area Custom Health Solutions',
    description: 'Regenerative & Functional Medicine • Hormone Therapy • IV Infusion Therapy • Medical Aesthetics — Coos Bay, OR',
    type: 'website',
    url: 'https://www.bayareachs.com/',
  },
  themeColor: '#1d4ed8',
  icons: [{ rel: 'icon', url: '/favicon.svg' }]
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav />
        <main id="main">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
