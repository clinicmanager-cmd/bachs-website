import Hero from '@/components/Hero'

export default function HomePage(){
  return (
    <>
      <Hero />
      <section className="section alt">
        <div className="container">
          <h2>Why BACH</h2>
          <div className="cards">
            <article className="card">
              <h3>Whole-person care</h3>
              <p>Root-cause evaluation and integrative plans tailored to your goals.</p>
            </article>
            <article className="card">
              <h3>Medical oversight</h3>
              <p>All medical decisions are overseen by our Medical Director, Margaret McLain, NP-C.</p>
            </article>
            <article className="card">
              <h3>Transparent pricing</h3>
              <p>Clear options and payment-friendly processes (HSA/FSA supported).</p>
            </article>
          </div>
        </div>
      </section>
    </>
  )
}
