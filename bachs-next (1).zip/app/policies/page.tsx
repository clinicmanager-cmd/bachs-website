export default function PoliciesPage(){
  return (
    <section className="section">
      <div className="container">
        <h1>Policies</h1>
        <ul>
          <li>Out-of-network: superbills provided upon request.</li>
          <li>Appointments: please arrive 10 minutes early.</li>
          <li>Cancellations: 24 hours notice appreciated.</li>
          <li>Medical care complies with applicable Oregon statutes and best practices.</li>
        </ul>
      </div>
    </section>
  )
}
