export default function ProvidersPage(){
  return (
    <section className="section">
      <div className="container">
        <h1>Providers</h1>
        <div className="cards">
          <article className="card">
            <h3>Margaret McLain, NP-C</h3>
            <p>Medical Director. Oversees all clinical decisions and patient protocols.</p>
          </article>
          <article className="card">
            <h3>Care Team</h3>
            <p>Registered nurses and staff delivering safe, patient-centered care.</p>
          </article>
        </div>
      </div>
    </section>
  )
}
