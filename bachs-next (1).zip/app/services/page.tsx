export default function ServicesPage(){
  return (
    <section className="section">
      <div className="container">
        <h1>Services</h1>
        <div className="cards">
          <article className="card">
            <h3>Regenerative & Functional Medicine</h3>
            <p>Root-cause assessment, targeted protocols, and lifestyle support.</p>
          </article>
          <article className="card">
            <h3>Hormone Therapy</h3>
            <p>Bioidentical HRT for men &amp; women with ongoing monitoring.</p>
          </article>
          <article className="card">
            <h3>IV Infusion Therapy</h3>
            <p>NAD+, recovery, hydration, and wellness drips administered in-clinic.</p>
          </article>
          <article className="card">
            <h3>Medical Aesthetics</h3>
            <p>Dermal fillers and adjunctive therapies performed by trained clinicians.</p>
          </article>
        </div>
      </div>
    </section>
  )
}
