export default function Footer(){
  const year = new Date().getFullYear();
  return (
    <footer>
      <div className="container">
        <p>© {year} Bay Area Custom Health Solutions • Coos Bay, OR</p>
        <a href="#top" className="to-top">Back to top ↑</a>
      </div>
    </footer>
  )
}
