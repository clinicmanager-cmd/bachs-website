import Link from 'next/link';

export default function Hero(){
  return (
    <section className="section">
      <div className="container grid-2">
        <div>
          <h1>Your Partners in Personalized, Regenerative Care</h1>
          <p className="lead">We help people in the Bay Area &amp; Coos Bay feel better and heal better with evidence-based, whole-person care.</p>
          <div className="actions">
            <Link href="/services" className="btn primary">Explore services</Link>
            <Link href="/forms" className="btn">New patient forms</Link>
          </div>
          <ul className="checks" style={{listStyle:'none', padding:0, marginTop:'1rem', color:'var(--muted)'}}>
            <li>✅ Regenerative & functional medicine</li>
            <li>✅ Hormone therapy (male &amp; female)</li>
            <li>✅ IV infusion therapy &amp; aesthetics</li>
          </ul>
        </div>
        <div className="card" role="img" aria-label="Preview card">
          <div style={{display:'grid', gap:'1rem'}}>
            <div className="kpis">
              <div><span style={{color:'var(--muted)', fontSize:'.85rem'}}>Visitors</span><div style={{fontWeight:800, fontSize:'1.5rem'}}>12,940</div></div>
              <div><span style={{color:'var(--muted)', fontSize:'.85rem'}}>Signups</span><div style={{fontWeight:800, fontSize:'1.5rem'}}>1,204</div></div>
              <div><span style={{color:'var(--muted)', fontSize:'.85rem'}}>Conversion</span><div style={{fontWeight:800, fontSize:'1.5rem'}}>9.3%</div></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
