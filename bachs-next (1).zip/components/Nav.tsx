import Link from 'next/link';
import Image from 'next/image';

export default function Nav(){
  return (
    <header>
      <nav className="nav container" aria-label="Primary">
        <Link href="/" className="brand" aria-label="Home">
          <Image src="/logo.svg" alt="BACH logo" width={28} height={28} priority />
          <span>Bay Area Custom Health Solutions</span>
        </Link>
        <ul>
          <li><Link href="/services">Services</Link></li>
          <li><Link href="/providers">Providers</Link></li>
          <li><Link href="/policies">Policies</Link></li>
          <li><Link href="/forms">Forms</Link></li>
        </ul>
      </nav>
    </header>
  )
}
